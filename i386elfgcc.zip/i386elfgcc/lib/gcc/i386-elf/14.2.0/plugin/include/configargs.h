/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-14.2.0/configure --target=i386-elf --prefix=/Users/yy/opt/i386elfgcc --disable-nls --disable-libssp --enable-languages=c --without-headers --with-gmp=/opt/homebrew/opt/gmp --with-mpfr=/opt/homebrew/opt/mpfr --with-mpc=/opt/homebrew/opt/libmpc";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "i386" }, { "arch", "i386" } };
